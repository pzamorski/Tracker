package com.example.tracker;

import android.Manifest;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import android.location.Criteria;
import android.location.LocationManager;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import static java.lang.Thread.sleep;

public class pracaWtle extends Service implements LocationListener {

    GlobalMethod config=new GlobalMethod(this);

    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    public static final String CHANNEL_ID2 = "ForegroundServiceChannel2";

    public static final String  DOJAZD_DO_CELU = "0";
    public static final String  DOJAZD_DO_CELU_GPS = "1";
    public static final String  WYJAZD_OD_CELU = "2";
    public static final String  WYJAZD_OD_CELU_GPS = "3";

    public static final int  POWER_SAVE_METER = 5000;//m
    public static final int  TIME_POWER_SAVE_METER_10m = 300000;//ms
    public static final int  TIME_MAX_POWER_METER = 0;//ms
    public static final int  TIME_POWER_SAVE_METER_1m = 60000;//ms

    public static final String  info = GlobalMethod.info;
    public static final String  stop = GlobalMethod.stop;
    public static final String  network = GlobalMethod.network;
    public static final String  gps = GlobalMethod.gps;
    public static final String  notyfication = GlobalMethod.notyfication;
    public static final String  bluetooh = GlobalMethod.bluetooh;



    private Handler handler = new Handler();
    private LocationManager locationManager;
    private String provider = LocationManager.NETWORK_PROVIDER;

    Location locationA = new Location("HOME");  //lokalizacja bramy
    Location location;

    double distance_in_meter;
    double distans_switch_to_gps;

    int RefreshLocationTime=0;//czas odswierzania lokalizacji 0 najszybsza
    int speed;
    int dystans_do_zadziałania;
    int dystans_do_wyjazdu;
    int incress_dyst_of_speed=0;


    @Override
    public void onCreate() {

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        config.init("global_para");
        config.init_log("main_logcat","log");
//dla bluetooh
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(mReceiver, filter);

//notyficacja
        createNotificationChannel();
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, 0);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Usługa lokalizacji")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentIntent(pendingIntent)
                .setGroup("data")
                .build();
        startForeground(1, notification);

//start jesli bluettoh triger nie właczony
        if (!config.getParaBoolean("trigerBluetoth")) {
            requestLocationUpdateNetwork();
        }

//zmienne przepisywane przy starcie usługi
        speed = config.getParaInt("speed");
        distans_switch_to_gps = config.getParaInt("distGPS");
        dystans_do_zadziałania = config.getParaInt("dist");
        dystans_do_wyjazdu = config.getParaInt("distKrok1");

            float homeLatitude = config.getParaFloat("lat");
            float homeLongitude = config.getParaFloat("lon");
            if (homeLatitude != 0) {
                locationA.setLatitude(homeLatitude);
            }
            if (homeLongitude != 0) {
                locationA.setLongitude(homeLongitude);
            }


        Toast.makeText(this, "Start usługi", Toast.LENGTH_SHORT).show();

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (location != null) { onLocationChanged(location); }
        config.log("Start",info);

        return Service.START_STICKY;
    }


    @Override
    public IBinder onBind(Intent intent) {
        //TODO for communication return IBinder implementation
        return null;
    }

    @Override
    public void onDestroy() {
        Toast.makeText(getApplicationContext(), "Stop usługi", Toast.LENGTH_SHORT).show();
        requestLocationUpdateStop();
        super.onDestroy();
        this.stopSelf();
    }

    @Override
    public void onLocationChanged(Location location) {

//Inicjalizacja
        float curentlat = (float) (location.getLatitude());
        float curentlng = (float) (location.getLongitude());
        float current_speed = (float) location.getSpeed();
        config.setPara("curentlat", curentlat);
        config.setPara("curentlng", curentlng);
        distance_in_meter = location.distanceTo(locationA);
        config.setPara("ui_dist",(int)distance_in_meter);
        String step= config.getParaString("krok");
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        int INTdistance_in_meter=(int)distance_in_meter;

//------główny watek--------------------------------------------------------------------------------
        switch (step) {
            case DOJAZD_DO_CELU:
                config.log("Strefa GPS: " + INTdistance_in_meter + " < " + distans_switch_to_gps,network);
                UpdateNoification("Czas: " + currentTime + "\nDojazd do strefy GPS");
                if (distance_in_meter < distans_switch_to_gps) {
                    config.log("W zasiegu dla GPS",network);
                    requestLocationUpdateGPS();
                    NextStep(DOJAZD_DO_CELU_GPS);
                }
                break;
            case DOJAZD_DO_CELU_GPS:
                config.log("Strefa Bramy: " + INTdistance_in_meter + " < " + dystans_do_zadziałania + " " + current_speed + " >= " + speed,gps);
                UpdateNoification("Czas: " + currentTime + "\nDojazd do bramy");
                if (distance_in_meter < (dystans_do_zadziałania+incress_dyst_of_speed) && current_speed >= speed) {
                    if(config.getParaBoolean("automat")==true){
                        config.log("Przygotowanie do otwarcia bramy",notyfication);
                        openGate(config.getParaString("link"));
                    }
                    requestLocationUpdateStop();
                    NextStep(WYJAZD_OD_CELU);// lub timeout dla gps do kroku DOJAZD_DO_CELU gps->network
                }
                break;
            case WYJAZD_OD_CELU:
                config.log("Wyjazd ze strefy: " + INTdistance_in_meter + " > " + dystans_do_wyjazdu,network);
                UpdateNoification("Czas: " + currentTime + "\nWyjazd ze strefy GPS");
                if (distance_in_meter > dystans_do_wyjazdu) {
                    config.log("Precyzyjny wyjazd z obszaru bramy",network);
                    requestLocationUpdateGPS();
                    NextStep(WYJAZD_OD_CELU_GPS);
                }
                break;
            case WYJAZD_OD_CELU_GPS:
                config.log("Precyzyjny wyjazd: " + INTdistance_in_meter + " > " + dystans_do_wyjazdu,gps);
                UpdateNoification("Czas: " + currentTime + "\nWyjazd ze strefy GPS");
                if (distance_in_meter > dystans_do_wyjazdu) {
                    config.log("Wyjazd z obszaru bramy",gps);
                    requestLocationUpdateNetwork();
                    NextStep(DOJAZD_DO_CELU); // lub timeout dla gps do kroku WYJAZD_OD_CELU gps->network
                }
                break;
        }
 //-----oszczedzanie energi-------------------------------------------------------------------------------
        if(distance_in_meter>POWER_SAVE_METER&&RefreshLocationTime!=TIME_POWER_SAVE_METER_1m){
            config.log("Power Save On",info);
            requestLocationUpdateStop();
            RefreshLocationTime=TIME_POWER_SAVE_METER_1m;
            requestLocationUpdateNetwork();
        }else if(distance_in_meter<POWER_SAVE_METER&&RefreshLocationTime!=TIME_MAX_POWER_METER){
            config.log("Power Save Off",info);
            requestLocationUpdateStop();
            RefreshLocationTime=TIME_MAX_POWER_METER;
            requestLocationUpdateNetwork();
        }
    }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onProviderEnabled(String provider) {
        Toast.makeText(this, "Enabled new provider " + provider,
                Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Disabled provider " + provider,
                Toast.LENGTH_SHORT).show();
    }

    //The BroadcastReceiver that listens for bluetooth broadcasts
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);


            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                //Device is now connected
                BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
                if(config.getParaString(device.getName()+"|"+device.getAddress()).equals(device.getName()+"|"+device.getAddress())&&config.getParaBoolean("trigerBluetoth")==true) {
                    config.log("Bluetooth Połączony: " + device.getName(),bluetooh);
                    UpdateNoification("Lokalizacja: Aktywna.");
                    requestLocationUpdateNetwork();
                }
            }
            else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)&&config.getParaBoolean("trigerBluetoth")==true) {
                //Device is about to disconnect
                if(config.getParaString(device.getName()+"|"+device.getAddress()).equals(device.getName()+"|"+device.getAddress())&&config.getParaBoolean("trigerBluetoth")==true) {
                    config.log("Bluetooth Rozłączony: " + device.getName(),bluetooh);
                    requestLocationUpdateStop();
                    UpdateNoification("Lokalizacja: Nie aktywna.");

                }
            }
        }
    };


    private void openGate(String url) {
        String URL = url;

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.equals("{\"success\":true}")) {
                            config.log("Otwieranie bramy",notyfication);
                            notyfication("Otwieram Brame");
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Check Error: ", "Error");
                        //Toast.makeText(MainActivity.this, (CharSequence) error, Toast.LENGTH_LONG).show();
                    }
                }
        ) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                return new byte[]{};

            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                return map;
            }
        };
        request.setRetryPolicy(new DefaultRetryPolicy(15000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_MAX_RETRIES));
        queue.add(request);

    }

    private void delayToNextStep(int czasOpoznienie, final String UstaWartoscKroku){
        // 120 seconds coundowntimer
        config.log("Opóznienie Kroku.",info);
        new CountDownTimer(czasOpoznienie*1000,1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {

                config.setPara("krok", UstaWartoscKroku);
                switch(config.getParaString("krok")){
                    case DOJAZD_DO_CELU:
                        config.log("Krok= DOJAZD_DO_CELU",info);
                        break;
                    case DOJAZD_DO_CELU_GPS:
                        config.log("Krok= DOJAZD_DO_CELU_GPS",info);
                        break;
                    case WYJAZD_OD_CELU:
                        config.log("Krok= WYJAZD_OD_CELU",info);
                        break;
                    case WYJAZD_OD_CELU_GPS:
                        config.log("Krok= WYJAZD_OD_CELU_GPS",info);
                        break;
                }
            }
        }.start();
    }

    private void NextStep(String NextTo){
                config.setPara("krok", NextTo);
        switch(config.getParaString("krok")){
            case DOJAZD_DO_CELU:
                config.log("Krok= DOJAZD_DO_CELU",info);
                break;
            case DOJAZD_DO_CELU_GPS:
                config.log("Krok= DOJAZD_DO_CELU_GPS",info);
                break;
            case WYJAZD_OD_CELU:
                config.log("Krok= WYJAZD_OD_CELU",info);
                break;
            case WYJAZD_OD_CELU_GPS:
                config.log("Krok= WYJAZD_OD_CELU_GPS",info);
                break;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    Context.NOTIFICATION_SERVICE,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    private void UpdateNoification(String string){
        createNotificationChannel();
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, 0);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Usługa lokalizacji")
                .setContentText(string)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentIntent(pendingIntent)
                .build();
        startForeground(1, notification);
    }


    private void notyfication(String tytuł){
        int importance = NotificationManager.IMPORTANCE_DEFAULT;
        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel("myChannelId", "My Channel", importance);
            channel.setDescription("Reminders");
            NotificationManager mNotificationManager =
                    (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.createNotificationChannel(channel);
        }



        NotificationCompat.Builder mBuilder =
                // Builder class for devices targeting API 26+ requires a channel ID
                new NotificationCompat.Builder(this, "myChannelId")
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        //.setContentTitle("Tracker:")
                        .setContentText(tytuł);

        NotificationManager mNotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
// mId allows you to update the notification later on.
        mNotificationManager.notify(2, mBuilder.build());
    }

    private void timeout(int s){

        new CountDownTimer(s*1000,1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {

                if(config.getParaString("krok").equals(DOJAZD_DO_CELU_GPS)){
                    config.log("Timeout Usługi 1",gps);
                notyfication("Timeout GPS");
                NextStep(DOJAZD_DO_CELU);
                requestLocationUpdateNetwork();}

                if(config.getParaString("krok").equals(WYJAZD_OD_CELU_GPS)){
                    config.log("Timeout Usługi 3",gps);
                    notyfication("Timeout GPS");
                    delayToNextStep(20,WYJAZD_OD_CELU);
                    requestLocationUpdateNetwork();}

            }
        }.start();
    }

    public void requestLocationUpdateNetwork(){

        if(locationManager!=null)
        {
            locationManager.removeUpdates(this);
            locationManager=null;
        }

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }

            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            provider = LocationManager.NETWORK_PROVIDER;

            locationManager.requestLocationUpdates(provider, RefreshLocationTime, 0, this);
        config.log("Start Lokalizacji." + provider,network);
    }

    public void requestLocationUpdateGPS(){

        if(locationManager!=null)
        {
            locationManager.removeUpdates(this);
            locationManager=null;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        provider = LocationManager.GPS_PROVIDER;

        locationManager.requestLocationUpdates(provider, 0, 0, this);
        timeout(config.getParaInt("timeout_gps"));
        config.log("Start Lokalizacji." + provider,gps);
    }

    public void requestLocationUpdateStop(){

        if(locationManager!=null)
        {
            config.log("Stop Lokalizacji." + provider,stop);
            locationManager.removeUpdates(this);
            locationManager=null;
        }
        RefreshLocationTime=TIME_MAX_POWER_METER;
    }


}